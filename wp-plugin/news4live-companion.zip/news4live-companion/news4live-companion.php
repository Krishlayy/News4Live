<?php
/**
 * Plugin Name: News 4 Live App Companion
 * Plugin URI: https://news4live.com/
 * Description: Official high-performance REST API companion and Firebase Cloud Messaging (FCM) push notification bridge for the News 4 Live Android application.
 * Version: 1.1.0
 * Author: News 4 Live Team
 * Author URI: https://news4live.com/
 * License: GPL-2.0+
 * Text Domain: news4live-companion
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class News4Live_Companion_Plugin {

    const VERSION = '1.1.0';
    const API_NAMESPACE = 'news4live/v1';
    const HOME_TRANSIENT_KEY = 'news4live_home_feed_cache';
    const TRANSIENT_EXPIRY = 120; // 2 minutes cache

    public function __construct() {
        // Register custom REST API routes
        add_action('rest_api_init', array($this, 'register_rest_routes'));

        // Push notification on post publish
        add_action('transition_post_status', array($this, 'handle_post_publish'), 10, 3);

        // Cache Invalidation on post updates
        add_action('save_post', array($this, 'invalidate_cache'));
        add_action('deleted_post', array($this, 'invalidate_cache'));

        // Admin settings
        if (is_admin()) {
            add_action('admin_menu', array($this, 'add_admin_menu'));
            add_action('admin_init', array($this, 'register_settings'));
            add_action('add_meta_boxes', array($this, 'add_breaking_meta_box'));
            add_action('save_post', array($this, 'save_breaking_meta_box'));
        }
    }

    /**
     * Invalidate transient cache when any post changes
     */
    public function invalidate_cache() {
        delete_transient(self::HOME_TRANSIENT_KEY);
    }

    /**
     * Register high-performance custom REST API routes
     */
    public function register_rest_routes() {
        // Aggregated Home endpoint with transient caching
        register_rest_route(self::API_NAMESPACE, '/home', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_home_feed'),
            'permission_callback' => '__return_true',
        ));

        // Breaking News endpoint
        register_rest_route(self::API_NAMESPACE, '/breaking', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_breaking_news'),
            'permission_callback' => '__return_true',
        ));

        // Trending News endpoint
        register_rest_route(self::API_NAMESPACE, '/trending', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_trending_news'),
            'permission_callback' => '__return_true',
        ));
    }

    /**
     * Aggregated Home Feed Handler with Transient Cache
     */
    public function get_home_feed($request) {
        // Check transient cache first
        $cached_feed = get_transient(self::HOME_TRANSIENT_KEY);
        if ($cached_feed !== false && !empty($cached_feed)) {
            return rest_ensure_response($cached_feed);
        }

        $breaking_cat_id = 31; // 'ब्रेकिंग न्यूज़'
        $top_cat_id      = 18; // 'टॉप न्यूज़'

        // 1. Breaking News
        $breaking_posts = $this->query_posts_formatted(array(
            'cat'            => $breaking_cat_id,
            'posts_per_page' => 5,
        ));

        // 2. Featured / Top Stories
        $featured_posts = $this->query_posts_formatted(array(
            'cat'            => $top_cat_id,
            'posts_per_page' => 6,
        ));

        // 3. Latest News
        $latest_posts = $this->query_posts_formatted(array(
            'posts_per_page' => 10,
        ));

        // 4. Categories list with counts
        $raw_cats = get_categories(array(
            'hide_empty' => true,
            'exclude'    => array(1), // Exclude Uncategorized
            'orderby'    => 'count',
            'order'      => 'DESC',
        ));

        $categories = array();
        foreach ($raw_cats as $cat) {
            $categories[] = array(
                'id'          => $cat->term_id,
                'name'        => html_entity_decode($cat->name, ENT_QUOTES, 'UTF-8'),
                'slug'        => $cat->slug,
                'count'       => (int) $cat->count,
                'parent'      => (int) $cat->parent,
                'description' => $cat->description,
            );
        }

        $response_data = array(
            'breaking'   => $breaking_posts,
            'featured'   => $featured_posts,
            'latest'     => $latest_posts,
            'categories' => $categories,
            'trending'   => $featured_posts,
        );

        // Store in transient for 2 minutes
        set_transient(self::HOME_TRANSIENT_KEY, $response_data, self::TRANSIENT_EXPIRY);

        return rest_ensure_response($response_data);
    }

    public function get_breaking_news($request) {
        $limit = $request->get_param('limit') ? (int) $request->get_param('limit') : 5;
        $posts = $this->query_posts_formatted(array(
            'cat'            => 31,
            'posts_per_page' => $limit,
        ));
        return rest_ensure_response($posts);
    }

    public function get_trending_news($request) {
        $limit = $request->get_param('limit') ? (int) $request->get_param('limit') : 10;
        $posts = $this->query_posts_formatted(array(
            'cat'            => 18,
            'posts_per_page' => $limit,
        ));
        return rest_ensure_response($posts);
    }

    /**
     * Helper to query and format posts matching the Android App DTO schema
     */
    private function query_posts_formatted($args) {
        $default_args = array(
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'orderby'        => 'date',
            'order'          => 'DESC',
            'no_found_rows'  => true,
            'update_post_term_cache' => true,
            'update_post_meta_cache' => true,
        );

        $query = new WP_Query(wp_parse_args($args, $default_args));
        $posts = array();

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $post_id = get_the_ID();

                $featured_image_id = get_post_thumbnail_id($post_id);
                $full_img_url   = $featured_image_id ? wp_get_attachment_image_url($featured_image_id, 'full') : null;
                $thumb_img_url  = $featured_image_id ? wp_get_attachment_image_url($featured_image_id, 'thumbnail') : null;
                $medium_img_url = $featured_image_id ? wp_get_attachment_image_url($featured_image_id, 'medium_large') : null;

                $categories = wp_get_post_categories($post_id);

                $media_sizes = array();
                if ($featured_image_id) {
                    $sizes_meta = wp_get_attachment_metadata($featured_image_id);
                    if (!empty($sizes_meta['sizes'])) {
                        foreach ($sizes_meta['sizes'] as $s_name => $s_val) {
                            $media_sizes[$s_name] = array(
                                'file'       => $s_val['file'],
                                'width'      => $s_val['width'],
                                'height'     => $s_val['height'],
                                'source_url' => wp_get_attachment_image_url($featured_image_id, $s_name),
                            );
                        }
                    }
                }

                $posts[] = array(
                    'id'       => $post_id,
                    'date'     => get_the_date('Y-m-d\TH:i:s'),
                    'modified' => get_the_modified_date('Y-m-d\TH:i:s'),
                    'slug'     => get_post_field('post_name', $post_id),
                    'link'     => get_permalink($post_id),
                    'title'    => array('rendered' => get_the_title()),
                    'content'  => array('rendered' => apply_filters('the_content', get_the_content())),
                    'excerpt'  => array('rendered' => get_the_excerpt()),
                    'featured_media' => (int) $featured_image_id,
                    'categories'     => $categories,
                    'tags'           => array(),
                    '_embedded'      => array(
                        'author' => array(
                            array(
                                'id'   => get_the_author_meta('ID'),
                                'name' => get_the_author(),
                            )
                        ),
                        'wp:featuredmedia' => $featured_image_id ? array(
                            array(
                                'id'         => (int) $featured_image_id,
                                'source_url' => $full_img_url,
                                'title'      => array('rendered' => get_the_title()),
                                'media_details' => array(
                                    'sizes' => $media_sizes,
                                )
                            )
                        ) : array(),
                    )
                );
            }
            wp_reset_postdata();
        }

        return $posts;
    }

    /**
     * Firebase Cloud Messaging Push Notification Handler with Duplicate Prevention
     */
    public function handle_post_publish($new_status, $old_status, $post) {
        // Only fire when post transitions to 'publish'
        if ($new_status !== 'publish' || $post->post_type !== 'post') {
            return;
        }

        // Prevent duplicate notification: Check if notification was already dispatched for this post ID
        $already_sent = get_post_meta($post->ID, '_news4live_notification_sent', true);
        $resend_requested = get_post_meta($post->ID, '_news4live_resend_notification', true);

        if ($already_sent === '1' && $resend_requested !== 'yes') {
            return; // Duplicate prevented!
        }

        $fcm_server_key = get_option('news4live_fcm_server_key', '');
        if (empty($fcm_server_key)) {
            return;
        }

        $post_id   = $post->ID;
        $title     = html_entity_decode(get_the_title($post_id), ENT_QUOTES, 'UTF-8');
        $excerpt   = wp_strip_all_tags(get_the_excerpt($post_id));
        $permalink = get_permalink($post_id);
        $image_id  = get_post_thumbnail_id($post_id);
        $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'medium_large') : '';

        $is_breaking = has_category(31, $post_id) || get_post_meta($post_id, '_news4live_is_breaking', true) === 'yes';
        $topic = $is_breaking ? 'breaking_news' : 'all_news';

        $payload = array(
            'to' => '/topics/' . $topic,
            'priority' => 'high',
            'data' => array(
                'post_id'     => (string) $post_id,
                'title'       => $title,
                'excerpt'     => mb_substr($excerpt, 0, 150, 'UTF-8'),
                'image'       => $image_url,
                'url'         => $permalink,
                'is_breaking' => $is_breaking ? '1' : '0',
            ),
            'notification' => array(
                'title'    => ($is_breaking ? '🔴 ब्रेकिंग: ' : '') . $title,
                'body'     => mb_substr($excerpt, 0, 100, 'UTF-8'),
                'image'    => $image_url,
                'sound'    => 'default',
            )
        );

        $response = wp_remote_post('https://fcm.googleapis.com/fcm/send', array(
            'headers' => array(
                'Authorization' => 'key=' . trim($fcm_server_key),
                'Content-Type'  => 'application/json; charset=utf-8',
            ),
            'body'        => wp_json_encode($payload),
            'timeout'     => 15,
            'blocking'    => true, // Block briefly to verify HTTP success
            'data_format' => 'body',
        ));

        // Only mark as sent if FCM returned success (HTTP 200)
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            update_post_meta($post_id, '_news4live_notification_sent', '1');
            delete_post_meta($post_id, '_news4live_resend_notification');
        }
    }

    /**
     * Admin Settings Page
     */
    public function add_admin_menu() {
        add_options_page(
            'News 4 Live App Settings',
            'News 4 Live App',
            'manage_options',
            'news4live-app',
            array($this, 'render_admin_page')
        );
    }

    public function register_settings() {
        register_setting('news4live_options_group', 'news4live_fcm_server_key');
    }

    public function render_admin_page() {
        ?>
        <div class="wrap">
            <h1>News 4 Live Android App — Plugin Settings</h1>
            <p>Configure Firebase Cloud Messaging (FCM) for automatic breaking news push notifications.</p>
            <form method="post" action="options.php">
                <?php
                settings_fields('news4live_options_group');
                do_settings_sections('news4live_options_group');
                ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Firebase Cloud Messaging (FCM) Server Key</th>
                        <td>
                            <input type="password" name="news4live_fcm_server_key" value="<?php echo esc_attr(get_option('news4live_fcm_server_key')); ?>" class="regular-text" />
                            <p class="description">Enter your Firebase Cloud Messaging Server Key from Firebase Console -> Project Settings -> Cloud Messaging.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Save Settings'); ?>
            </form>
            <hr />
            <h2>API Diagnostics</h2>
            <p><strong>Custom Aggregated Endpoint:</strong> <code><?php echo esc_url(rest_url('news4live/v1/home')); ?></code></p>
            <p><strong>Transient Cache Status:</strong> <?php echo get_transient(self::HOME_TRANSIENT_KEY) ? '<span style="color:green;">Cached (Active)</span>' : '<span style="color:orange;">Not Cached (Will regenerate on next call)</span>'; ?></p>
        </div>
        <?php
    }

    /**
     * Breaking News Meta Box in Post Editor
     */
    public function add_breaking_meta_box() {
        add_meta_box(
            'news4live_breaking_box',
            'News 4 Live App — Notification Controls',
            array($this, 'render_breaking_meta_box'),
            'post',
            'side',
            'high'
        );
    }

    public function render_breaking_meta_box($post) {
        $is_breaking = get_post_meta($post->ID, '_news4live_is_breaking', true);
        $already_sent = get_post_meta($post->ID, '_news4live_notification_sent', true);
        ?>
        <p>
            <label>
                <input type="checkbox" name="news4live_is_breaking" value="yes" <?php checked($is_breaking, 'yes'); ?> />
                <strong>Mark as Breaking News</strong> (🔴 Alert)
            </label>
        </p>
        <?php if ($already_sent === '1') : ?>
            <p style="color:#666; font-size:12px;">
                <em>✓ Push notification was already sent for this post.</em>
            </p>
            <p>
                <label>
                    <input type="checkbox" name="news4live_resend_notification" value="yes" />
                    Resend Push Notification on Update
                </label>
            </p>
        <?php else : ?>
            <p style="color:#666; font-size:12px;">
                <em>Push notification will be sent automatically when published.</em>
            </p>
        <?php endif; ?>
        <?php
    }

    public function save_breaking_meta_box($post_id) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;

        if (isset($_POST['news4live_is_breaking'])) {
            update_post_meta($post_id, '_news4live_is_breaking', 'yes');
        } else {
            delete_post_meta($post_id, '_news4live_is_breaking');
        }

        if (isset($_POST['news4live_resend_notification'])) {
            update_post_meta($post_id, '_news4live_resend_notification', 'yes');
        }
    }
}

new News4Live_Companion_Plugin();
